// tan.h
#ifndef TAN_H
#define TAN_H

double my_tan(double angle);

#endif // TAN_H
