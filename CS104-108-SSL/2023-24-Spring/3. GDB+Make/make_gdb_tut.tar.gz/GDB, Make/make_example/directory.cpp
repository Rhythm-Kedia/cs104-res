// directory.cpp
#include "directory.h"
#include <iostream>

void Directory::create() {
    std::cout << "Directory created: " << name << std::endl;
}
